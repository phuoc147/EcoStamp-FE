import { LocationProvider } from "./context/LocationContext";

export default function ConsumerSigninLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <LocationProvider>{children}</LocationProvider>;
}
